class Player {
  // Member Variables
  int x, y, w, h, score;
  PImage p1, p2;

  // Constructor
  Player(int x, int y) {
    this.x = x;
    this.y = y;
    w = 40;
    h = 40;
    score = 0;
    p1 = loadImage("Player1.png");
    p2 = loadImage("Player2.png");
  }

  // Member Methods
  void display() {
    imageMode(CENTER);
    image(p1, x, y);

    if (x < -20) {
      x = width+20;
    }
    if (x > width+20) {
      x = -20;
    }
    if (y < -20) {
      y = height+20;
    }
    if (y > height+20) {
      y = -20;
    }
  }

  void move(char direction) {
    if (direction == 'w') {
      y-=10;
    } else if (direction == 's') {
      y = y + 10;
    } else if (direction == 'a') {
      x-=10;
    } else if (direction == 'd') {
      x = x + 10;
    }
  }
}
