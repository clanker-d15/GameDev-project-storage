// Franklin Roth | Aug 25 2026 | ShapeGame
// Global Variables
Target t1, t2, t3;
Player p1, p2;
int countDown, CountX, CountColor;
PImage bg1;

void setup() {
  size(500, 700);
  background(50);
  t1 = new Target();
  t2 = new Target();
  t3 = new Target();
  CountX = 270;
  CountColor = (255);
  countDown = 1000;
  p1 = new Player(width/2, height/2);
  p2 = new Player(width/2, height/2);
  bg1 = loadImage("Background1.png");
}

void draw() {
  background(50);

  imageMode(CENTER);
  tint(255, 120);
  image(bg1, 250, 350);
  filter(BLUR);
  noTint();

  stroke(0);

  // Target
  t1.display();
  t2.display();
  t3.display();

  scorePanel();

  p1.display();
  p2.display();

  // Collision
  if (t1.wasHit(p1) == true) {
    t1.relocate();
  }
  if (t2.wasHit(p1) == true) {
    t2.relocate();
  }
  if (t3.wasHit(p1) == true) {
    t3.relocate();
  }
  if (t1.wasHit(p2) == true) {
    t1.relocate();
  }
  if (t2.wasHit(p2) == true) {
    t2.relocate();
  }
  if (t3.wasHit(p2) == true) {
    t3.relocate();
  }


  countDown = countDown - 1;
  if (countDown < 0) {
    textAlign(CENTER);
    textSize(50);
    fill(#C60202);
    text("GAME OVER!", width/2, height/2);
    text("P1 Score: " + p1.score, width/2, 400);
    text("P2 Score: " + p2.score, width/2, 450);
    noLoop();
  }
}

void keyPressed() {

  // WASD Movement
  if (key == 's' || key == 'S') {
    p1.move('s');
  } else if (key == 'w' || key == 'W') {
    p1.move('w');
  } else if (key == 'd' || key == 'D') {
    p1.move('d');
  } else if (key == 'a' || key == 'A') {
    p1.move('a');
  }

  // Arrow Key Movement
  if (key == CODED) {
    if (keyCode == UP) {
      p2.move('w');
    } else if (keyCode == DOWN) {
      p2.move('s');
    } else if (keyCode == RIGHT) {
      p2.move('d');
    } else if (keyCode == LEFT) {
      p2.move('a');
    }
  }
}


void scorePanel() {
  fill(27, 83, 205, 127);
  rectMode(CORNER);
  rect(0, 0, width, 30);
  fill(255);
  textSize(16);
  text("P1 Score: " + p1.score, 5, 27);
  text("P2 Score: " + p2.score, 5, 13);
  textSize(32);
  fill(CountColor);
  text("Count Down: " + countDown, CountX, 25);

  // countDown stylizer
  if (countDown > 600) {
    CountColor = (255);
  }
  if (countDown < 600) {
    CountColor = (#FCBDBD);
  }

  if (countDown < 250) {
    CountColor = (#F55252);
  }

  if (countDown < 100) {
    CountX = 285;
    CountColor = (#D30202);
  }
  if (countDown < 10) {
    CountX = 300;
  }
}
