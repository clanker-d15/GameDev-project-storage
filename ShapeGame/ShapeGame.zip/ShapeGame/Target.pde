// Note: Find a way to prevent the targets from overlapping with one another

class Target {
  // Member Variables (properties or atributes)
  int x, y, size;
  color c1;
  PImage tar1;

  // Constructor (Give all member variables their 1st value)
  Target() {
    x = int(random(15, 485));
    y = int(random(15, 685));
    size = int(random(40, 70));
    c1 = color(random(60, 120), random(60, 140), random(60, 200));
    tar1 = loadImage("");
  }

  // Member Methods (Everything the target can do)
  void display() {
    fill(c1);
    ellipse(x, y, size, size);
  }

  void relocate() {
    // mimic behavior of game tab
    x = int(random(15, 485));
    y = int(random(15, 675));
    p1.score = p1.score + 100;
    countDown = 1000;

    // Shape spawn on player debugger
    if (p1.score > 99 && countDown > 998) {
      p1.score = 0;
    } else if (p2.score > 99 && countDown > 998) {
      p2.score = 0;
    }
  }

  boolean wasHit(Player p) {
    // boolean return type for collision
    // distance
    float d = dist(x, y, p.x, p.y);

    if (d<size) {
      return true;
    } else {
      return false;
    }
  }
}
